# Mini-version-QQ
自己写的一个盗版QQ
